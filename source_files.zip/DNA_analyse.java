/**
 * 
 * @author Gerhart Mende
 * 
 * 
 */

// Main class, to start the program
public class DNA_analyse {
	
	static Window w;
	final static String EXAMPLE_DNA = new String("ggaatttagggagttcccacattgcccagacgactcgtatagaattggtagttggccatg"
										+	"cgtccatatcacaaagacacagtccctggccgaccacactgtaaccacgaatatgcccta"
										+	"tcgtacgggttgggatgcacttttgagttatacgcgctcgaatctatgcccagtacacat"
										+	"ggtgccgacacctaactaggcagtgaggggcactcagacctgacatgagcggaagaaaga"
										+	"acccgcgggggccccacgacgtagcggcgacggctcaaccaatgccccgcccctttcata"
										+	"aggccaagcggactgggctttcgcccgagtctaaacccactgtatttaccattcatagtc"
										+	"aacagagggactttcaaaattcctaaactggttactgactaagaggaatcctcgcgctaa"
										+	"tgaagacaacctccatagaggtcaaatggcgcgcagttgacttcagtattgaccttcttc"
										+	"agggtcccccatctttgatacttcacttatggacccggccaccgtgagttgaatcccggc"
										+	"gtccctcgcgtccccaacacagacaatatttttacgtgtccaagggcggaaagtgacgag"
										+	"gtgagaactggcgccgcgagaccggcccgatttctaataggcgggatagagatctgcccg"
										+	"acgcatttcacttgtagtcactcacggtatgactgtgcatgcactgaccgtcgctggcgt"
										+	"gtctttaatttaagctaggcttgacgtggagtgcagaatgaccatgttcaaggtgcttcg"
										+	"gggctatatacttgggataaacgcgatcctgcggagtagcgtcgagaacaccgactgccg"
										+	"aatgtacaatccgcgtgacaatgccgaggctcgagatatcacttgaactgcgggcgaatc"
										+	"gattcgagagcccgatcgttaacaagtcgtcggctgtagccaataatatcttggttttag"
										+	"atcttgagtgtgggggcgtttacttaaccatccgaacgcg");
	
	public static void main(String[] args){
		
		w = new Window();
	}		
}
	
	

